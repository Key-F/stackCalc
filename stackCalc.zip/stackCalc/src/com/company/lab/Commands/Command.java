package com.company.lab.Commands;

public interface Command {
    void execute(); // Метод интерфейса, который необходимо реализовать
}
