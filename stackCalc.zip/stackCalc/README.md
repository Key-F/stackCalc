# stackCalc
 
